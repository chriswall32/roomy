( function(angular) {
	angular
		.module("application", ["ngRoute"])
		.config(function($locationProvider, $routeProvider) {
			$locationProvider.html5Mode(true);

			$routeProvider
				.when("/exercise1", {
					template: '<div>HELLO</div>'
				})
				.when("/exercise2", {
					template: '<div>GOODBYE</div>'
				});
		});
} (window.angular));